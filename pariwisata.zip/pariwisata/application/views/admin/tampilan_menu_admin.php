<ul class="nav nav-list">
  <li class="active">
    <a href="<?php echo base_url();?>Administrator">
      <i class="icon-home"></i>
      <span class="menu-text"> Dashboard </span>
    </a>
  </li>

  <li>
    <a href="<?php echo base_url();?>hotel_admin">
      <i class="icon-hospital"></i>
      <span class="menu-text"> Hotel </span>
    </a>
  </li>

  <li>
    <a href="<?php echo base_url();?>Wisata_admin">
      <i class="icon-compass"></i>
      <span class="menu-text"> Wisata </span>
    </a>
  </li>

  <li>
    <a href="gallery.html">
      <i class="icon-food"></i>
      <span class="menu-text"> Kuliner </span>
    </a>
  </li>

  <li>
    <a href="<?php echo base_url();?>Testimoni">
      <i class="icon-text-width"></i>
      <span class="menu-text"> Testimoni </span>
    </a>
  </li>
</ul><!--/.nav-list-->
