ini tampilan pos hotel
